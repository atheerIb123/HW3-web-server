#include <stdbool.h>
#include "segel.h"
#include "request.h"
#include "Queue.h"

void getArguments(int *port, int *numOfThreads, int* queueSize, char scheduling[7], int* maxSize, int argc, char *argv[])
{
    if (argc < 5)
    {
        fprintf(stderr, "Usage: %s <port> <threads_num> <queue_size> <schedalg>\n", argv[0]);
        exit(1);
    }

    *port = atoi(argv[1]);
    *numOfThreads = atoi(argv[2]);
    *queueSize = atoi(argv[3]);
    strcpy(scheduling, argv[4]);

    if(strcmp(argv[4], "dynamic") == 0)
    {
        if(argc >= 6)
        {
            *maxSize = atoi(argv[5]);
        }
    }
}

Queue* waitingRequestsQueue;
Queue* nowHandlingRequestsQueue;

pthread_cond_t waitingNotEmpty;
pthread_mutex_t m_queue;
pthread_cond_t notFullQueue;
pthread_mutex_t fullQueue;

void* workerFunc(void* arg) {
    int id = *(int*)arg;
    free(arg);
    Stats stats = malloc(sizeof (*stats));

    stats->handlerId = id;
    stats->handlerReqCount = 0;
    stats->handlerStaticReqCount = 0;
    stats->handlerDynamicReqCount = 0;

    struct timeval pickTime;
    while (1)
    {
        pthread_mutex_lock(&m_queue);
        while (waitingRequestsQueue->size == 0)
        {
            pthread_cond_wait(&waitingNotEmpty, &m_queue);
        }

        Request* request_to_handle = getFirstRequest(waitingRequestsQueue);
        Dequeue(waitingRequestsQueue);

        gettimeofday(&pickTime,NULL);
        timersub(&pickTime, &request_to_handle->arrive, &request_to_handle->dispatch);
        stats->dispatch = request_to_handle->dispatch;
        stats->arrival = request_to_handle->arrive;


        node* reqNode = addToQueue(nowHandlingRequestsQueue, request_to_handle);

        pthread_mutex_unlock(&m_queue);

        struct timeval startTime;
        gettimeofday(&startTime,NULL);

        requestHandle(request_to_handle->confd,stats);

        struct timeval completedTime;
        gettimeofday(&completedTime,NULL);
        struct timeval durationOfHandling;
        timersub(&completedTime, &startTime, &durationOfHandling);

        Close(request_to_handle->confd);
        free(request_to_handle);

        pthread_mutex_lock(&m_queue);
        removeFromQueue(nowHandlingRequestsQueue, reqNode);

        pthread_cond_signal(&notFullQueue);
        pthread_mutex_unlock(&m_queue);
    }
    free(stats);
}

int main(int argc, char *argv[])
{
    int listenFD, connFD, port, numOfThreads, queueSize, lengthOfClient, maxSize;
    bool addPolicy;
    char scheduling[8];
    struct sockaddr_in addrOfClient;
    struct timeval arrivalTime;

    pthread_mutex_init(&m_queue, NULL);
    pthread_cond_init(&waitingNotEmpty, NULL);
    pthread_mutex_init(&fullQueue, NULL);
    pthread_cond_init(&notFullQueue, NULL);

    getArguments(&port, &numOfThreads, &queueSize, scheduling, &maxSize, argc, argv);

    nowHandlingRequestsQueue = createQueue();
    waitingRequestsQueue = createQueue();

    pthread_t* listOfThreads = (pthread_t*) malloc(numOfThreads * sizeof(pthread_t));

    for (int i = 0; i < (int) numOfThreads; i++)
    {
        int* passId = malloc(sizeof(int));
        *passId = i;
        pthread_create(&listOfThreads[i], NULL,  workerFunc, passId);
    }

    listenFD = Open_listenfd(port);

    while (1)
    {
        addPolicy = false;
        lengthOfClient = sizeof(addrOfClient);
            connFD = Accept(listenFD, (SA *) &addrOfClient, (socklen_t *) &lengthOfClient);
        gettimeofday(&arrivalTime,NULL);

        if (waitingRequestsQueue->size + nowHandlingRequestsQueue->size >= queueSize) {

            if(strcmp(scheduling,"block") == 0)
            {
                pthread_mutex_lock(&fullQueue);

                while (waitingRequestsQueue->size + nowHandlingRequestsQueue->size >= queueSize)
                {
                    pthread_cond_wait(&notFullQueue, &fullQueue);
                }

                pthread_mutex_unlock(&fullQueue);
            }
            else if (strcmp(scheduling,"dh") == 0)
            {
                if(waitingRequestsQueue->size != 0)
                {
                    pthread_mutex_lock(&m_queue);
                    Close(waitingRequestsQueue->head->data->confd);
                    free(waitingRequestsQueue->head->data);
                    Dequeue(waitingRequestsQueue);
                    pthread_mutex_unlock(&m_queue);
                }
                else
                {
                    Close(connFD);
                    addPolicy = true;
                }
            }
            else if (strcmp(scheduling, "dt") == 0)
            {
                Close(connFD);
                addPolicy = true;
            }
            else if(strcmp(scheduling, "bf") == 0)
            {
                pthread_mutex_lock(&fullQueue);

                while(waitingRequestsQueue->size > 0 && nowHandlingRequestsQueue->size > 0)
                {
                    pthread_cond_wait(&waitingNotEmpty, &fullQueue);
                }

                pthread_mutex_unlock(&fullQueue);
                Close(connFD);
            }
            else if(strcmp(scheduling, "dynamic") == 0)
            {
                queueSize++;

                if (queueSize == maxSize) //drop tail policy
                {
                    Close(connFD);
                    addPolicy = true;
                }
            }
            else if (strcmp(scheduling, "random") == 0)
            {
                if(nowHandlingRequestsQueue->size >= queueSize)
                {
                    Close(connFD);
                    addPolicy = true;
                }
                else
                {
                    pthread_mutex_lock(&m_queue);

                    int toDrop = (waitingRequestsQueue->size + 1) / 2;

                    for(int i = 0; i < toDrop; i++)
                    {
                        int randIndex = rand() % waitingRequestsQueue->size;
                        removeByIndex(waitingRequestsQueue, randIndex);
                    }

                    pthread_mutex_unlock(&m_queue);
                }
            }

        }

        if (addPolicy != true)
        {
            Request* request = malloc(sizeof(*request));
            request->confd = connFD;
            request->arrive=arrivalTime;
            pthread_mutex_lock(&m_queue);

            addToQueue(waitingRequestsQueue, request);

            pthread_cond_signal(&waitingNotEmpty);
            pthread_mutex_unlock(&m_queue);
        }

    }

    destroyAndCloseDFds(nowHandlingRequestsQueue);
    destroy(waitingRequestsQueue);

    for (int i = 0; i < numOfThreads; i++) {
        pthread_join(listOfThreads[i], NULL);
    }

    free(listOfThreads);
}


 
